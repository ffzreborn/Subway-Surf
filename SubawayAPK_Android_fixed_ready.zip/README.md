# Subaway Android APK — WebView fixed

Proyecto Android adaptado específicamente para `subaway_android_device.html`.

## Cambios principales
- WebView con JavaScript y DOM Storage habilitados.
- `WebViewAssetLoader` para cargar el HTML desde un origen HTTPS local de la app; esto ayuda a que `fetch`, `localStorage` y APIs web funcionen de forma consistente.
- Selector nativo de archivos conectado mediante `WebChromeClient` para los dos archivos auxiliares del HTML.
- Zoom del WebView desactivado.
- Se conservan los botones, pestañas y generadores del HTML.
- Se corrigen las condiciones de los selectores Android que quedaron inconsistentes después del cambio de plataforma.
- Se restauran los desplazamientos internos del sidebar, contenido y generadores sin permitir desplazamiento de toda la página.

## Compilación gratuita con GitHub
1. Sube todos estos archivos al repositorio, respetando las carpetas.
2. Abre **Actions**.
3. Ejecuta **Build APK**.
4. Descarga el artifact **Subaway-debug-apk**.
